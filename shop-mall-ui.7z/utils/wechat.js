// auth 授权登陆
const authLogin = (API) => {
  // console.log(API.API)
  return new Promise((resolve, reject) => {
    uni.login({
      success: (res) => {
        console.log(res.code, 222);
        resolve();
        // 发送 res.code 到后台换取 openId, sessionKey, unionId(多个微信平台才能获取)
        // API.request({
        //   url: "/wechat/login",
        //   method: "get",
        //   params: {
        //     wechatcode: res.code,
        //   },
        // }).then((userInfo) => {
        //   resolve(userInfo);
        // });
      },
    });
  });
};

module.exports = {
  authLogin,
};
