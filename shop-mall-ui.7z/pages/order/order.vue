<template>
	<view class="content"> </view>
</template>

<script>
	export default {
		data() {
			return {
				title: '首页'
			}
		},
		onLoad() {},
		methods: {}
	}
</script>

<style></style>
