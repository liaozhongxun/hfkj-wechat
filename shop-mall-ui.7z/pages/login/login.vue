<template>
	<view class="login-page page">
		<view class="content">养老商城</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello'
			}
		},
		onLoad() {},
		methods: {}
	}
</script>

<style></style>
