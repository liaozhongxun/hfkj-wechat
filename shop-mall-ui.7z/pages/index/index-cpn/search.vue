<template>
	<view class="home-search">
		<view class="location" >位置定位</view>
		<view class="search">
			<!-- <van-search v-model="value" placeholder="请输入商品/店铺/地点"/> -->
			<view class="search-"></view>
		</view>
		<view class="scan">
			<van-icon class="van-icon" name="scan" size="50rpx"/>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello'
			}
		},
		onLoad() {},
		methods: {
			$go(){
				uni.switchTab({ 
				    url: 'pages/sub/position/position'
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.home-search {
		width: 100%;
		height: 88rpx;
		display: flex;
		line-height: 88rpx;
		.location{
			width:160rpx;
			text-align: center;
			height: 22px;
			font-size: 16px;
			font-weight: 400;
			color: #333333;
		}
		.search{
			flex:1;
			background: #00f;
			
		}
		.scan{
			width: 88rpx;
			.van-icon{
				width: 88rpx;
				height: 88rpx;
				text-align: left;
				line-height: 88rpx;
				color:#333
			}
		}
	}
</style>
