<template>
	<view class="content">
		<HomeSearch class="search"></HomeSearch>
<!-- 		<van-button type="danger">危险按钮</van-button>
		<button type="default">dd</button>
		<uni-icons type="contact" size="30"></uni-icons> -->
	</view>
</template>

<script>
	import HomeSearch from './index-cpn/search.vue'
	export default {
		data() {
			return {
				title: 'Hello00'
			}
		},
		components: {
			HomeSearch
		},
		onLoad() {},
		methods: {}
	}
</script>

<style></style>
