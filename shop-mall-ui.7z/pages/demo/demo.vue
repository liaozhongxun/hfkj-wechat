<template>
	<view class="content"> </view>
</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello'
			}
		},
		onLoad() {},
		methods: {}
	}
</script>

<style></style>
